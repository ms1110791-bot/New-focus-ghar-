package com.focusghar.app

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp

/** onResume par badalta hai, taaki Accessibility ki permission wapas aane par UI turant update ho. */
object UiBus {
    var tick by mutableIntStateOf(0)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT))
        // Pehle front page dikhao; baaki sab uske baad.
        setContent { AppTheme { Root() } }
        Reminder.schedule(this)
    }

    override fun onResume() {
        super.onResume()
        UiBus.tick++
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val p = remember { Prefs.sp(ctx) }
    var tab by rememberSaveable { mutableStateOf(0) }
    val items = listOf("🛡️" to "Block", "✅" to "Today", "🎯" to "Goals")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (emoji, label) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(emoji, fontSize = 20.sp) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            // Sirf chuna hua tab load hota hai (lazy), isliye ऐप तेज़ खुलता है.
            when (tab) {
                0 -> BlockTab(p)
                1 -> TodayTab(p)
                else -> YearTab(p)
            }
        }
    }
}
