package com.focusghar.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private fun accOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return s.contains(BlockService::class.java.name)
}

private fun clock(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format("%02d:%02d", s / 60, s % 60)
}

@Composable
fun BlockTab(p: SharedPreferences) {
    val ctx = LocalContext.current
    var master by remember { mutableStateOf(p.getBoolean("master", true)) }
    var yt by remember { mutableStateOf(p.getBoolean("yt", true)) }
    var ig by remember { mutableStateOf(p.getBoolean("ig", true)) }
    var red by remember { mutableStateOf(p.getBoolean("redirect", true)) }
    var counter by remember { mutableStateOf(p.getBoolean("count", true)) }
    var debug by remember { mutableStateOf(p.getBoolean("debug", false)) }
    var focusUntil by remember { mutableLongStateOf(p.getLong("focusUntil", 0L)) }
    var pauseUntil by remember { mutableLongStateOf(p.getLong("pauseUntil", 0L)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showApps by remember { mutableStateOf(false) }
    var ids by remember { mutableStateOf("") }

    val tick = UiBus.tick
    val acc = remember(tick) { accOn(ctx) }
    // Reel counts are refreshed every time the app comes to the front.
    val today = remember(tick) { Data.reels(p, Data.today()) }
    val week = remember(tick) { Data.weekReels(p) }

    // The timer only runs while focus/pause is active; otherwise nothing is running.
    LaunchedEffect(focusUntil, pauseUntil) {
        while (focusUntil > System.currentTimeMillis() || pauseUntil > System.currentTimeMillis()) {
            now = System.currentTimeMillis()
            delay(1000)
        }
        now = System.currentTimeMillis()
    }

    fun putB(k: String, v: Boolean) = p.edit().putBoolean(k, v).apply()
    fun putL(k: String, v: Long) = p.edit().putLong(k, v).apply()

    val focusing = focusUntil > now
    val pausing = pauseUntil > now

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(
            "Focus Ghar",
            if (focusing) "Focus mode is on 🔥" else "Block reels. Stop sneaky redirects.",
            R.drawable.ic_logo
        )

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            if (!acc) {
                Panel {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⚠️ Permission needed", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "Focus Ghar uses Android's Accessibility Service only to notice Shorts/Reels " +
                                "screens and apps opened by ads, then it presses Back. " +
                                "Nothing on your screen is stored or sent anywhere.",
                            fontSize = 14.sp
                        )
                        Button(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("Open settings") }
                    }
                }
            }

            // ---- Reel counter + brain ----
            if (counter) {
                val total = today.first + today.second
                val level = (total / 60f).coerceIn(0f, 1f)
                val mood = when {
                    total < 10 -> "Fresh brain 🧠"
                    total < 30 -> "Getting foggy 😵"
                    total < 60 -> "Brain rot loading… 🥴"
                    else -> "Fully fried 💀"
                }
                Panel {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Brain(level, Modifier.size(110.dp))
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Shorts/Reels watched today", fontSize = 13.sp)
                            Text("$total", fontSize = 44.sp, fontWeight = FontWeight.Bold)
                            Text(mood, fontWeight = FontWeight.SemiBold)
                            Text(
                                "YouTube ${today.first} · Instagram ${today.second} · 7 days $week",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }

            // ---- Focus mode ----
            Panel {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🎯 Focus mode", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (focusing) {
                        Text(clock(focusUntil - now), fontSize = 44.sp, fontWeight = FontWeight.Bold)
                        Text("All blocks are forced on", fontSize = 13.sp)
                        Button(onClick = {
                            focusUntil = 0L
                            putL("focusUntil", 0L)
                        }) { Text("Stop") }
                    } else {
                        Text("One tap turns every block on, with a timer", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(25, 60, 120).forEach { m ->
                                Button(onClick = {
                                    val t = System.currentTimeMillis() + m * 60_000L
                                    focusUntil = t
                                    putL("focusUntil", t)
                                }) { Text("$m min") }
                            }
                        }
                    }
                }
            }

            // ---- ON/OFF buttons ----
            Panel {
                Column {
                    ToggleRow("▶️", "Block YouTube Shorts", "On = Shorts close as soon as they open", yt) {
                        yt = it
                        putB("yt", it)
                    }
                    ToggleRow("📸", "Block Instagram Reels", "On = Reels close as soon as they open", ig) {
                        ig = it
                        putB("ig", it)
                    }
                    ToggleRow("🔗", "Block redirects", "If an ad opens Chrome/Play Store/another app, go back", red) {
                        red = it
                        putB("redirect", it)
                    }
                    ToggleRow("📊", "Reel counter", "Count the Shorts/Reels you watch", counter) {
                        counter = it
                        putB("count", it)
                    }
                    ToggleRow("⚡", "App enabled", "Off = everything stops", master) {
                        master = it
                        putB("master", it)
                    }
                }
            }

            // ---- Pause ----
            Panel {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⏸️ Short break", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (pausing) {
                        Text("Time left: ${clock(pauseUntil - now)}", fontSize = 14.sp)
                        Button(onClick = {
                            pauseUntil = 0L
                            putL("pauseUntil", 0L)
                        }) { Text("Resume blocking") }
                    } else {
                        Text("Want to watch Shorts/Reels? Pause blocking for a bit", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(15, 30).forEach { m ->
                                OutlinedButton(onClick = {
                                    val t = System.currentTimeMillis() + m * 60_000L
                                    pauseUntil = t
                                    putL("pauseUntil", t)
                                }) { Text("$m min") }
                            }
                        }
                    }
                }
            }

            OutlinedButton(onClick = { showApps = true }, modifier = Modifier.fillMaxWidth()) {
                Text("✅ Apps allowed to open")
            }

            // ---- Debug ----
            Panel {
                Column {
                    ToggleRow("🛠️", "Debug mode", "If blocking doesn't work, show screen IDs", debug) {
                        debug = it
                        putB("debug", it)
                    }
                    if (debug) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Open YouTube/Instagram, go to a Short/Reel, come back here and tap Refresh.",
                                fontSize = 12.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { ids = p.getString("last_ids", "") ?: "" }) {
                                    Text("Refresh")
                                }
                                OutlinedButton(onClick = {
                                    copyText(ctx, ids)
                                    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                                }) { Text("Copy") }
                            }
                            if (ids.isNotEmpty()) Text(ids, fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showApps) AllowedDialog(p) { showApps = false }
}

@Composable
private fun AllowedDialog(p: SharedPreferences, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var sel by remember { mutableStateOf(Prefs.allowed(p).toSet()) }

    // The app list is built in the background so the UI never freezes.
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .filter { it.second != ctx.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } },
        title = { Text("Allowed apps") },
        text = {
            Column {
                Text(
                    "Let these apps open from YouTube/Instagram (for example WhatsApp sharing).",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(8.dp))
                val list = apps
                if (list == null) {
                    CircularProgressIndicator()
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(list) { (label, pkg) ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        sel = if (pkg in sel) sel - pkg else sel + pkg
                                        p.edit().putStringSet("allowed", HashSet(sel)).apply()
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = pkg in sel, onCheckedChange = null)
                                Text(label, modifier = Modifier.padding(start = 12.dp))
                            }
                        }
                    }
                }
            }
        }
    )
}
