package com.focusghar.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Indigo = Color(0xFF6C63FF)
val Violet = Color(0xFF9B5DE5)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val cs = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF8F89FF),
            onPrimary = Color.White,
            background = Color(0xFF0E1020),
            surface = Color(0xFF181C32),
            onBackground = Color(0xFFEDEEFF),
            onSurface = Color(0xFFEDEEFF),
            surfaceVariant = Color(0xFF222742),
            secondaryContainer = Color(0xFF2B2F55)
        )
    } else {
        lightColorScheme(
            primary = Indigo,
            onPrimary = Color.White,
            background = Color(0xFFF4F5FF),
            surface = Color.White,
            onBackground = Color(0xFF1B1D2E),
            onSurface = Color(0xFF1B1D2E),
            surfaceVariant = Color(0xFFE9EBFF),
            secondaryContainer = Color(0xFFE0DEFF)
        )
    }
    MaterialTheme(colorScheme = cs, content = content)
}

/** Gradient header with a logo for each section. */
@Composable
fun Header(title: String, sub: String, icon: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.linearGradient(listOf(Indigo, Violet)))
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Image(painterResource(icon), contentDescription = null, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
        }
    }
}

/** Rounded card. */
@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        content = content
    )
}

@Composable
fun ToggleRow(
    emoji: String,
    title: String,
    sub: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 26.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(
                sub,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/**
 * A brain that gets duller, greener and cracked as the reel count grows.
 * level: 0f = fresh brain, 1f = fully fried.
 */
@Composable
fun Brain(level: Float, modifier: Modifier = Modifier) {
    val base = lerp(Color(0xFFFF8FB1), Color(0xFF8A9A5B), level)
    val line = lerp(Color(0xFFD6568A), Color(0xFF4B5A33), level)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = w * 0.016f, cap = StrokeCap.Round)

        // two hemispheres
        drawOval(base, topLeft = Offset(w * 0.06f, h * 0.14f), size = Size(w * 0.48f, h * 0.72f))
        drawOval(base, topLeft = Offset(w * 0.46f, h * 0.14f), size = Size(w * 0.48f, h * 0.72f))
        // middle line
        drawLine(line, Offset(w * 0.5f, h * 0.2f), Offset(w * 0.5f, h * 0.82f), strokeWidth = w * 0.018f, cap = StrokeCap.Round)
        // folds
        listOf(0.27f to 0.36f, 0.73f to 0.36f, 0.30f to 0.62f, 0.70f to 0.62f).forEach { (x, y) ->
            drawArc(
                color = line,
                startAngle = 200f,
                sweepAngle = 230f,
                useCenter = false,
                topLeft = Offset(w * x - w * 0.08f, h * y - w * 0.08f),
                size = Size(w * 0.16f, w * 0.16f),
                style = stroke
            )
        }
        // rot spots
        if (level > 0.3f) {
            drawCircle(line.copy(alpha = 0.55f), radius = w * 0.04f, center = Offset(w * 0.34f, h * 0.5f))
            drawCircle(line.copy(alpha = 0.55f), radius = w * 0.03f, center = Offset(w * 0.66f, h * 0.45f))
        }
        // cracks
        if (level > 0.6f) {
            drawLine(line, Offset(w * 0.64f, h * 0.2f), Offset(w * 0.58f, h * 0.36f), strokeWidth = w * 0.014f, cap = StrokeCap.Round)
            drawLine(line, Offset(w * 0.58f, h * 0.36f), Offset(w * 0.64f, h * 0.46f), strokeWidth = w * 0.014f, cap = StrokeCap.Round)
            drawLine(line, Offset(w * 0.3f, h * 0.76f), Offset(w * 0.38f, h * 0.64f), strokeWidth = w * 0.014f, cap = StrokeCap.Round)
        }
    }
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("focus", text))
}

/** Free way: copy everything, open the Claude app (or claude.ai), then paste. */
fun sendToClaude(ctx: Context, text: String) {
    copyText(ctx, text)
    Toast.makeText(ctx, "Copied ✅ Paste it in Claude", Toast.LENGTH_LONG).show()
    try {
        val launch = ctx.packageManager.getLaunchIntentForPackage("com.anthropic.claude")
        if (launch != null) {
            ctx.startActivity(launch)
        } else {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://claude.ai/new"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    } catch (e: Exception) {
        Toast.makeText(ctx, "Couldn't open Claude. Open it yourself and paste.", Toast.LENGTH_LONG).show()
    }
}
