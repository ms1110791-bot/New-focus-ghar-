package com.focusghar.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

/**
 * Blocks Shorts/Reels and unwanted redirects, and counts Shorts/Reels you watch.
 * It recognises the Shorts/Reels screen by its view IDs and presses Back.
 */
class BlockService : AccessibilityService() {

    private val yt = "com.google.android.youtube"
    private val ig = "com.instagram.android"

    // View IDs of the Shorts/Reels player. They can change when YouTube/Instagram update;
    // Debug mode in the app shows the current IDs.
    private val ytIds = listOf(
        "com.google.android.youtube:id/reel_player_page_container",
        "com.google.android.youtube:id/reel_watch_fragment_root"
    )
    private val igIds = listOf(
        "com.instagram.android:id/clips_viewer_view_pager",
        "com.instagram.android:id/clips_swipe_refresh_container"
    )

    private lateinit var p: SharedPreferences
    private var neutral: Set<String> = emptySet()
    private var ime: Set<String> = emptySet()
    private var foreground: String? = null
    private var inShorts = false
    private var lastCheck = 0L
    private var lastCount = 0L
    private var lastBack = 0L
    private var backCount = 0
    private var lastRedirect = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        p = Prefs.sp(this)
        refreshSets()
    }

    override fun onInterrupt() {}

    private fun refreshSets() {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val home = packageManager.queryIntentActivities(homeIntent, 0).map { it.activityInfo.packageName }
        neutral = (home + listOf(
            "com.android.systemui",
            "android",
            "com.google.android.gms",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            "com.google.android.packageinstaller",
            packageName
        )).toSet()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        ime = imm.enabledInputMethodList.map { it.packageName }.toSet()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val ev = e ?: return
        val pkg = ev.packageName?.toString() ?: return
        val type = ev.eventType

        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) onWindow(pkg)

        // Only YouTube/Instagram events go further; everything else is dropped early to stay fast.
        if (pkg != yt && pkg != ig) return
        val scroll = type == AccessibilityEvent.TYPE_VIEW_SCROLLED
        if (!scroll &&
            type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return
        if (!p.getBoolean("master", true)) return

        val now = SystemClock.uptimeMillis()
        val toggle = if (pkg == yt) Prefs.yt(p) else Prefs.ig(p)
        val blockOn = toggle && Prefs.active(p)
        val countOn = p.getBoolean("count", true)
        val debug = p.getBoolean("debug", false)

        if (scroll) {
            // A swipe inside Shorts/Reels = next video. Only needed for counting.
            if (!countOn || blockOn || now - lastCount < 900) return
        } else {
            if (now - lastCheck < 350) return
            lastCheck = now
        }
        if (!blockOn && !countOn && !debug) return

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        if (debug && !scroll) {
            val found = linkedSetOf<String>()
            collect(root, found, 0)
            p.edit().putString("last_ids", pkg + "\n" + found.joinToString("\n")).apply()
        }

        val ids = if (pkg == yt) ytIds else igIds
        val hit = ids.any { root.findAccessibilityNodeInfosByViewId(it)?.isNotEmpty() == true }

        if (hit) {
            if (blockOn) {
                block(now)
            } else if (countOn && (!inShorts || scroll) && now - lastCount >= 900) {
                lastCount = now
                Data.addReel(p, pkg == yt)
            }
        }
        inShorts = hit
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        if (n == null || depth > 25 || out.size > 80) return
        n.viewIdResourceName?.let { out.add(it) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    private fun block(now: Long) {
        if (now - lastBack < 700) return
        backCount = if (now - lastBack < 3000) backCount + 1 else 1
        lastBack = now
        if (backCount >= 3) {
            backCount = 0
            performGlobalAction(GLOBAL_ACTION_HOME)
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
        Toast.makeText(this, "Shorts/Reels blocked 🚫", Toast.LENGTH_SHORT).show()
    }

    /** A new window opened: if another app opened right after YouTube/Instagram, send the user back. */
    private fun onWindow(pkg: String) {
        if (pkg in ime) return
        val prev = foreground
        foreground = pkg
        if (prev != pkg) inShorts = false
        if (prev == null || prev == pkg) return
        if (prev != yt && prev != ig) return
        if (pkg == yt || pkg == ig) return
        if (!Prefs.active(p) || !Prefs.redirect(p)) return
        if (pkg in neutral || pkg in Prefs.allowed(p)) return

        val now = SystemClock.uptimeMillis()
        if (now - lastRedirect < 1200) return
        lastRedirect = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        Toast.makeText(this, "Redirect blocked ✋", Toast.LENGTH_SHORT).show()
    }
}
