package com.focusghar.app

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TodayTab(p: SharedPreferences) {
    val ctx = LocalContext.current
    val date = remember { Data.today() }
    var tasks by remember { mutableStateOf<List<Task>?>(null) }
    var input by remember { mutableStateOf("") }
    var daily by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // Header pehle dikhta hai, kaam baad me background se aate hain.
    LaunchedEffect(Unit) {
        tasks = withContext(Dispatchers.IO) { Data.tasks(p, date) }
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            perm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val list = tasks

    fun save(l: List<Task>) {
        tasks = l
        Data.saveTasks(p, date, l)
    }

    fun add() {
        val t = input.trim()
        val cur = list ?: return
        if (t.isEmpty()) return
        save(cur + Task(t, daily = daily))
        if (daily) {
            val r = Data.routine(p)
            if (t !in r) Data.saveRoutine(p, r + t)
        }
        input = ""
    }

    Column(Modifier.fillMaxSize()) {
        Header("Today", SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), R.drawable.ic_sec_today)

        if (list == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    val total = list.size
                    val done = list.count { it.done }
                    Panel {
                        Column(Modifier.padding(16.dp)) {
                            Text(
                                if (total == 0) "Plan your day ✍️" else "$done / $total tasks done",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (total > 0) {
                                Spacer(Modifier.height(10.dp))
                                LinearProgressIndicator(
                                    progress = { done.toFloat() / total },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    if (done == total) "Great job! Everything is done 🎉"
                                    else "${total - done} left. What got in the way? Tap 📝 to write it down.",
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                item {
                    Panel {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = input,
                                onValueChange = { input = it },
                                label = { Text("Add a task") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { add() })
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = daily, onCheckedChange = { daily = it })
                                Text("🔁 Repeat daily", modifier = Modifier.weight(1f), fontSize = 14.sp)
                                Button(onClick = { add() }) { Text("Add") }
                            }
                        }
                    }
                }

                itemsIndexed(list) { i, t ->
                    TaskRow(
                        t = t,
                        onToggle = {
                            save(list.mapIndexed { j, x -> if (j == i) x.copy(done = !x.done) else x })
                        },
                        onWhy = { w ->
                            save(list.mapIndexed { j, x -> if (j == i) x.copy(why = w) else x })
                        },
                        onDelete = {
                            if (t.daily) Data.saveRoutine(p, Data.routine(p).filter { it != t.text })
                            save(list.filterIndexed { j, _ -> j != i })
                        }
                    )
                }

                item {
                    Button(
                        onClick = { sendToClaude(ctx, Data.export(p)) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🤖 Talk to Claude (copies your data)") }
                }
            }
        }
    }
}

@Composable
private fun TaskRow(
    t: Task,
    onToggle: () -> Unit,
    onWhy: (String) -> Unit,
    onDelete: () -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Panel {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = t.done, onCheckedChange = { onToggle() })
                Text(
                    (if (t.daily) "🔁 " else "") + t.text,
                    modifier = Modifier.weight(1f),
                    textDecoration = if (t.done) TextDecoration.LineThrough else null,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (t.done) 0.5f else 1f)
                )
                if (!t.done) TextButton(onClick = { open = !open }) { Text("📝") }
                TextButton(onClick = onDelete) { Text("🗑️") }
            }
            if (open && !t.done) {
                OutlinedTextField(
                    value = t.why,
                    onValueChange = onWhy,
                    label = { Text("Why didn't this happen?") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            } else if (!t.done && t.why.isNotBlank()) {
                Text(
                    "💭 ${t.why}",
                    fontSize = 12.sp,
                    modifier = Modifier.padding(start = 16.dp, bottom = 8.dp),
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}
