# फोकस घर — APK कैसे बनाएँ

1. GitHub पर नया repo बनाओ और इस पूरे फोल्डर की फाइलें डालो (`.github` फोल्डर भी!).
2. Repo में **Actions** टैब → **Build APK** → **Run workflow**.
3. 4-5 मिनट बाद उसी run में नीचे **Artifacts → FocusGhar-APK** डाउनलोड करो.
4. ज़िप खोलकर `app-debug.apk` फोन में इंस्टॉल करो ("unknown source" की अनुमति दो).
5. ऐप खोलो → "सेटिंग खोलें" → Accessibility में **फोकस घर** चालू करो.

## अगर Shorts/Reels ब्लॉक न हों
ऐप में **Debug मोड** चालू करो → YouTube/Insta में Shorts/Reels खोलो → फोकस घर में वापस आकर
"ताज़ा करो" → "कॉपी" → वो लिस्ट Claude को भेज दो, ID सही कर दी जाएगी.

## अगर बिल्ड फेल हो
Actions में लाल run खोलो, नीचे का error text कॉपी करके भेज दो.
